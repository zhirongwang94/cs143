
<!-- -->
<!DOCTYPE html>
<html lang="en">
				<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width, initial-scale=1">
				<meta name="description" content="">
				<meta name="author" content="">
				<link rel="icon" href="#">
				<title>Home-代码狗的BLOG</title>
				<style> 
					.tabs{
						tab-size: 6;
					}

				</style>



				</head>



<!-- Inside Body, there are a lot of division, one by one, displayed on the site-->
<body class="frontpage">

<!--This division is for the study of text division -->
<div class="pagehead">

		<h1>代码狗的BLOG</h1>
		<pre>爱国、爱党、爱世界</pre>	
		<pre>"种下去的是代码，收获的是bug"             
				---码农农场</pre>
</div>


<!--This division is for the study of linking (link to) other sites -->
<div class="menu-outer">
    <nav> <!-- Navigation tag -->
	    <ul>  <!--Unordered list tag,  -->
           <li><a href="home.html">Home</a></li> <!-- a tag, a tag to conatain a hyperlink  -->
           <li><a href="projects.html">Projects</a></li>
           <li><a href="notes.html">Notes</a></li>
           <li><a href="lifes.html">生活</a></li>
           <li><a href="about.html">About</a></li>
        </ul>
   </nav>
</div>



<!--Division of Empty Space-->
<div>
	<pre>
		

	</pre>
</div>


<div>
	<pre>Recent post:</pre>
</div>

<!--Division of Link to Github-->
<div>
	<pre>
		

	</pre>	
	<pre>GitHub</pre>
</div>


<!--Division of Tags-->
<div>	
	<pre>
		

	</pre>
	<h4>TAGS</h4>
</div>

</body>
</html>


