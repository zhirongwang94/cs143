db.laureates.find({'knownName.en': "Marie Curie"}, { _id: 0, id: 1})

